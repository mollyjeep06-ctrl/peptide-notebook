$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $env:JAVA_HOME) {
  $studioJava = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
  if (Test-Path "$studioJava\bin\java.exe") { $env:JAVA_HOME = $studioJava }
}
if (-not $env:JAVA_HOME -or -not (Test-Path "$env:JAVA_HOME\bin\java.exe")) {
  throw 'Install Android Studio or set JAVA_HOME to JDK 17 or 21, then try again.'
}
if (-not $env:ANDROID_HOME) { $env:ANDROID_HOME = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path "$env:ANDROID_HOME\platforms\android-35\android.jar")) {
  throw 'Android Studio > SDK Manager > SDK Platforms: install Android 15 (API 35), then run again.'
}
$gradleVersion = '8.9'
$toolDir = Join-Path $PSScriptRoot '.build-tools'
New-Item -ItemType Directory -Force $toolDir | Out-Null
$gradle = Join-Path $toolDir "gradle-$gradleVersion\bin\gradle.bat"
if (-not (Test-Path $gradle)) {
  $archive = Join-Path $toolDir 'gradle.zip'
  $url = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
  Invoke-WebRequest -UseBasicParsing $url -OutFile $archive
  $expected = ((Invoke-WebRequest -UseBasicParsing "$url.sha256").Content).Trim().ToLower()
  $actual = (Get-FileHash $archive -Algorithm SHA256).Hash.ToLower()
  if ($expected -notmatch '^[a-f0-9]{64}$' -or $expected -ne $actual) { throw 'Gradle checksum mismatch. Build stopped.' }
  Expand-Archive $archive -DestinationPath $toolDir -Force
  Remove-Item $archive
}
& $gradle --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Build failed. See the error above.' }
Copy-Item 'app\build\outputs\apk\debug\app-debug.apk' 'Peptide-Notebook-test.apk' -Force
Write-Host "APK ready: $PSScriptRoot\Peptide-Notebook-test.apk"
