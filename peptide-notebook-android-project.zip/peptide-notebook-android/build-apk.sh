#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -z "${JAVA_HOME:-}" && -d '/Applications/Android Studio.app/Contents/jbr/Contents/Home' ]]; then
 export JAVA_HOME='/Applications/Android Studio.app/Contents/jbr/Contents/Home'
fi
if [[ -z "${JAVA_HOME:-}" ]]; then echo 'Set JAVA_HOME to JDK 17 or 21.'; exit 1; fi
if [[ -z "${ANDROID_HOME:-}" ]]; then
 if [[ "$(uname)" == 'Darwin' ]]; then export ANDROID_HOME="$HOME/Library/Android/sdk"; else export ANDROID_HOME="$HOME/Android/Sdk"; fi
fi
if [[ ! -f "$ANDROID_HOME/platforms/android-35/android.jar" ]]; then echo 'Install Android 15 (API 35) in Android Studio SDK Manager.'; exit 1; fi
mkdir -p .build-tools
gradle_bin='.build-tools/gradle-8.9/bin/gradle'
if [[ ! -f "$gradle_bin" ]]; then
 url='https://services.gradle.org/distributions/gradle-8.9-bin.zip'
 curl --fail --location "$url" --output .build-tools/gradle.zip
 expected="$(curl --fail --location "$url.sha256")"
 actual="$(shasum -a 256 .build-tools/gradle.zip | cut -d ' ' -f 1)"
 if [[ ! "$expected" =~ ^[a-f0-9]{64}$ || "$actual" != "$expected" ]]; then echo 'Gradle checksum mismatch'; exit 1; fi
 unzip -q .build-tools/gradle.zip -d .build-tools
 rm .build-tools/gradle.zip
fi
bash "$gradle_bin" --no-daemon assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk Peptide-Notebook-test.apk
printf '%s\n' "APK ready: $PWD/Peptide-Notebook-test.apk"
