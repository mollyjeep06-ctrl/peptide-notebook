package com.tad.peptidenotebook;
import android.content.*;
public class RefreshReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){try{ReminderStore.refresh(c);}catch(Exception e){android.util.Log.e("Notebook","Refresh failed",e);}}}
