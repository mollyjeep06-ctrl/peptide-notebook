package com.tad.peptidenotebook;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.Build;import android.content.pm.PackageManager;import org.json.*;import java.time.*;import java.util.*;
final class ReminderStore {
 static final String CHANNEL="notebook_reminders";
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("notebook_native",Context.MODE_PRIVATE);}
 static JSONObject snapshot(Context c){try{return new JSONObject(prefs(c).getString("snapshot","{}"));}catch(Exception e){return new JSONObject();}}
 static boolean uk(Context c){return snapshot(c).optString("language").equals("uk");}
 static long at(JSONObject e){try{return LocalDateTime.parse(e.getString("date")+"T"+e.getString("time")).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();}catch(Exception error){return 0;}}
 static boolean permission(Context c){return (Build.VERSION.SDK_INT<33||c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==PackageManager.PERMISSION_GRANTED)&&c.getSystemService(NotificationManager.class).areNotificationsEnabled();}
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
 static PendingIntent pending(Context c,String id){Intent i=new Intent(c,ReminderReceiver.class).setData(Uri.parse("notebook://reminder/"+Uri.encode(id))).putExtra("eventId",id);return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static List<JSONObject> future(Context c){List<JSONObject> out=new ArrayList<>();JSONArray events=snapshot(c).optJSONArray("events");if(events!=null)for(int i=0;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e!=null&&at(e)>System.currentTimeMillis())out.add(e);}out.sort(Comparator.comparingLong(ReminderStore::at));return out;}
 static synchronized JSONObject sync(Context c,JSONObject data)throws Exception{if(data.optInt("version")!=1||data.optJSONArray("events")==null)throw new Exception("Invalid schedule");prefs(c).edit().putString("snapshot",data.toString()).commit();return refresh(c);}
 static synchronized JSONObject refresh(Context c)throws Exception {
  AlarmManager alarms=c.getSystemService(AlarmManager.class);JSONArray old=new JSONArray(prefs(c).getString("scheduled","[]"));for(int i=0;i<old.length();i++)alarms.cancel(pending(c,old.getString(i)));
  NotificationManager manager=c.getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Peptide Notebook",NotificationManager.IMPORTANCE_DEFAULT));
  boolean enabled=prefs(c).getBoolean("enabled",false),allowed=permission(c),precise=exact(c);JSONArray ids=new JSONArray();String until="";
  if(enabled&&allowed){List<JSONObject> next=future(c);for(JSONObject e:next.subList(0,Math.min(next.size(),60))){long time=at(e);if(precise){try{alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending(c,e.getString("id")));}catch(SecurityException denied){precise=false;alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending(c,e.getString("id")));}}else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending(c,e.getString("id")));ids.put(e.getString("id"));until=e.getString("date")+" "+e.getString("time");}}
  prefs(c).edit().putString("scheduled",ids.toString()).commit();NotebookWidget.refreshAll(c);
  return new JSONObject().put("enabled",enabled).put("permission",allowed).put("exact",precise).put("scheduled",ids.length()).put("until",until);
 }
}
