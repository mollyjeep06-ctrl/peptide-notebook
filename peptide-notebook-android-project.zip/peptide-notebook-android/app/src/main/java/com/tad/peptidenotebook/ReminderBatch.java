package com.tad.peptidenotebook;
// Deliver all events at this instant before refreshing/cancelling expired alarms.
final class ReminderBatch {
 static boolean includes(long eventTime,long targetTime,long now){
  return targetTime>0 && eventTime==targetTime && now>=targetTime && now-targetTime<=3600000L;
 }
}
