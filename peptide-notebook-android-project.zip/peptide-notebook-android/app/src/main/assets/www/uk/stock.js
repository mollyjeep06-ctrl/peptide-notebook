'use strict';
function stockBalance(v,entries=state.entries,excludeId=''){
  const related=entries.filter(e=>e.vialId===v.id&&e.id!==excludeId);
  const used=related.reduce((sum,e)=>sum+e.dose,0),total=v.mass*1000;
  const raw=total-used,tolerance=Math.max(total,used,1)*Number.EPSILON*16;
  const remaining=Math.abs(raw)<=tolerance?0:Math.max(0,raw);
  return {total,used,remaining,percent:remaining/total*100,count:related.length,excess:raw < -tolerance ? -raw : 0};
}
function normaliseStock(data){
  // Legacy free-text links are converted only when peptide and vial label identify exactly one vial.
  const norm=s=>String(s??'').trim().toLowerCase().replace(/\s+/g,' ');
  const entries=data.entries.map(e=>{
    if(typeof e.vialId==='string')return e;
    const matches=data.vials.filter(v=>norm(v.peptide)===norm(e.peptide)&&norm(e.vial)!==''&&[norm(v.number),norm('#'+v.number),norm(v.peptide+' #'+v.number)].includes(norm(e.vial)));
    return {...e,vialId:matches.length===1?matches[0].id:''};
  });
  return {...data,entries,vials:data.vials.map(v=>({...v,remaining:stockBalance(v,entries).percent}))};
}
function entryVialLabel(e){const v=state.vials.find(v=>v.id===e.vialId);return v?v.peptide+' #'+v.number:e.vial||'Не вибрано'}
function entryVialCell(e){const linked=state.vials.some(v=>v.id===e.vialId);return `${esc(entryVialLabel(e))}${linked?'':'<br><span class="stock-unlinked">Не прив’язано — без списання</span>'}`}
function unlinkedStockNotice(){const count=state.entries.filter(e=>!state.vials.some(v=>v.id===e.vialId)).length;return count?`<div class="notice">Записів без прив’язки до флакона: <b>${count}</b>. Відкрийте їх у журналі й виберіть флакон, щоб врахувати витрату. <a href="#journal">Відкрити журнал</a></div>`:''}
function stockVialPicker(record,required){return `<label class="full">Флакон для списання<select name="vialId" ${required?'required':''}><option value="">Виберіть флакон</option>${state.vials.map(v=>{const b=stockBalance(v,state.entries,record.id);return `<option value="${esc(v.id)}" ${record.vialId===v.id?'selected':''}>${esc(v.peptide)} #${esc(v.number)} · доступно ${precise(b.remaining/1000)} мг</option>`}).join('')}</select></label>${record.vial&&!record.vialId?`<p class="unit full">Попередній запис: ${esc(record.vial)}. Виберіть конкретний флакон для обліку витрати.</p>`:''}<div id="stock-preview" class="notice full"></div>`}
function bindStockForm(record){
  const form=$('#record-form'),picker=form.querySelector('[name="vialId"]'),dose=form.querySelector('[name="dose"]'),peptide=form.querySelector('[name="peptide"]');
  function update(){const v=state.vials.find(v=>v.id===picker.value);peptide.readOnly=!!v;if(!v){$('#stock-preview').textContent=state.vials.length?'Виберіть флакон: витрата розраховується за фактичною дозою в мкг.':'Спочатку додайте флакон у розділі «Флакони».';return}peptide.value=v.peptide;const b=stockBalance(v,state.entries,record.id),amount=Number(dose.value);if(!Number.isFinite(amount)||amount<=0){$('#stock-preview').textContent=`До цього запису: ${precise(b.remaining/1000)} мг. Введіть дозу в мкг.`;return}const after=b.total-b.used-amount;$('#stock-preview').textContent=after < -1e-8?`Витрата перевищить вміст флакона на ${precise(-after/1000)} мг. Перевірте дозу та вибраний флакон. Запис фактичного введення можна зберегти; перевищення буде показано в переліку флаконів.`:`Після збереження залишиться ${precise(Math.max(0,after)/1000)} мг (${precise(Math.max(0,after)/b.total*100)}%).`}
  picker.addEventListener('change',update);dose.addEventListener('input',update);update();
}
function stockAmount(v){const b=stockBalance(v);return `<strong>${precise(b.remaining/1000)} мг</strong><div class="row-meta">${fmt(b.percent,2)}% · списано ${precise(b.used/1000)} мг</div>${b.excess?`<div class="error">Перевищення: ${precise(b.excess/1000)} мг</div>`:''}`}
