'use strict';
const protocolReferences=[
 {id:'retatrutide',name:'RETATRUTIDE',range:'1–12 мг/нед; до 15 мг — утверждение автора',review:'Исследуемый препарат. Lilly сообщает, что ретатрутид не одобрен FDA. Присланная схема не является проверенным назначением; автоматически переносить её дозы в календарь нельзя.',url:'https://www.lilly.com/news/stories/what-to-know-about-retatrutide',source:'Lilly: статус ретатрутида',text:`Дозы: 1-12 мг/нед (допускают до 15 мг по переносимости).
Длительность: можно длительно; ориентируемся на цель и переносимость.

ПРОТОКОЛ:
Если нет опыта с GLP-1 (Ozempic/ Mounjaro и т.л.): старт первая неделя 1 мг/нед., проверяем переносимость, и поднимаем до 2.5 ко второй неделе, держим дозировку 3-4 недели, далее титруем по необходимости.
Если опыт был с GLP-1 (Ozempic/ Mounjaro и т.п.): начальную дозу выбираем в контексте прежних доз и переносимости.

ПОБОЧНЫЕ ЭФФЕКТЫ:
Тошнота, диарея/запор, отрыжка, тяжесть в желудке (чаще в начале), возможен небольшой рост ЧСС.
Редко: панкреатит, гипогликемия.

ПРОТИВОПОКАЗАНИЯ:
Беременность, лактация, возраст <18 лет, тяжёлые заболевания печени и почек, индивидуальная непереносимость. Осторожно при анамнезе панкреатита и выраженном гастропарезе.`},
 {id:'tirzepatide',name:'TIRZEPATIDE',range:'1–15 мг/нед — текст автора',review:'В присланном тексте есть расхождение: инструкция Zepbound (США, август 2026) предусматривает старт 2,5 мг еженедельно на 4 недели; дальнейшее повышение — не раньше 4 недель на текущей дозе. Это справка, а не персональная схема. Исходный список противопоказаний также неполон: в инструкции указаны медуллярный рак щитовидной железы в личном/семейном анамнезе и МЭН-2. Конкретную схему и препарат определяет врач.',url:'https://pi.lilly.com/us/zepbound-uspi.pdf',source:'Lilly: полная инструкция Zepbound',text:`Дозы: 1-15 мг/нед.
Длительность: можно длительно; ориентируемся на цель и переносимость.

ПРОТОКОЛ:
Если нет опыта с GLP-1: старт первая неделя 1 мг/нед., проверяем переносимость, и поднимаем до 2.5 ко второй неделе, держим дозировку 3-4 недели, далее титруем по необходимости.
Если опыт был с GLP-1 (Ozempic/ Mounjaro и т.п.): начальную дозу выбираем в контексте прежних доз и переносимости.

ПОБОЧНЫЕ ЭФФЕКТЫ:
Тошнота, диарея/запор, отрыжка, тяжесть в желудке (чаще в начале), возможен небольшой рост ЧСС.
Редко: панкреатит, гипогликемия.

ПРОТИВОПОКАЗАНИЯ:
Беременность, лактация, возраст <18 лет, тяжёлые заболевания печени и почек, индивидуальная непереносимость. Осторожно при анамнезе панкреатита и выраженном гастропарезе.`},
 {id:'cagrilintide',name:'CAGRILINTIDE',range:'0,3–4,5 мг/нед — текст автора',review:'В исходном тексте не указана длительность этапов повышения дозы: фраза заканчивается на «по». Диапазон, совместное применение и перерывы не подтверждены здесь как назначение. Для календаря нужна конкретная схема от специалиста; приложение не достраивает её автоматически.',url:'https://www.novonordisk.com/science-and-technology/r-d-pipeline.html',source:'Novo Nordisk: программа исследований',text:`Дозы: 0.3-4.5 мг/нед.
Длительность: можно длительно; ориентируемся на цель и переносимость (часто делают перерыв на 1 месяц каждые 4 месяца).

ПРОТОКОЛ:
Старт: 0.3 мг/нед.
Далее при необходимости титрация:
0.6 → 1.2 → 2.4 → 4.5 мг/нед по
Если используется вместе с GLP-1: титруем медленнее; многим хватает диапазона 0.3-1.2 мг/нед.

ПОБОЧНЫЕ ЭФФЕКТЫ:
Тошнота, чувство переполнения/ тяжесть, иногда запор или диарея (чаще на старте и при повышении дозы). Редко: гипогликемия при сочетании с инсулином/ сульфонилмочевиной.

ПРОТИВОПОКАЗАНИЯ:
Беременность, лактация, возраст <18 лет, выраженный гастропарез, индивидуальная непереносимость.
С осторожностью при низком весе и при терапии инсулином (может потребоваться снижение доз).`}
];
protocolReferences.push(...extraProtocolReferences);
const ukrainianReferences={
retatrutide:{review:'Досліджуваний препарат. Lilly повідомляє, що ретатрутид не схвалений FDA. Надіслана схема не є перевіреним призначенням; автоматично переносити її дози в календар не можна.',text:`Дози: 1-12 мг/тиж (допускають до 15 мг за переносимістю).
Тривалість: можна тривало; орієнтуємося на мету й переносимість.

ПРОТОКОЛ:
Якщо немає досвіду з GLP-1 (Ozempic/ Mounjaro тощо): старт першого тижня 1 мг/тиж., перевіряємо переносимість і підвищуємо до 2.5 до другого тижня, тримаємо дозування 3-4 тижні, далі титруємо за потреби.
Якщо досвід із GLP-1 (Ozempic/ Mounjaro тощо) був: початкову дозу вибираємо з урахуванням попередніх доз і переносимості.

ПОБІЧНІ ЕФЕКТИ:
Нудота, діарея/закреп, відрижка, важкість у шлунку (частіше на початку), можливе невелике зростання ЧСС.
Рідко: панкреатит, гіпоглікемія.

ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, тяжкі захворювання печінки й нирок, індивідуальна непереносимість. Обережно за наявності панкреатиту в анамнезі та вираженого гастропарезу.`},
tirzepatide:{review:'У надісланому тексті є розбіжність: інструкція Zepbound (США, серпень 2026) передбачає старт 2,5 мг щотижня протягом 4 тижнів; подальше підвищення — не раніше ніж через 4 тижні на поточній дозі. Це довідка, а не персональна схема. Початковий перелік протипоказань також неповний: в інструкції вказані медулярний рак щитоподібної залози в особистому/сімейному анамнезі та МЕН-2. Конкретну схему й препарат визначає лікар.',text:`Дози: 1-15 мг/тиж.
Тривалість: можна тривало; орієнтуємося на мету й переносимість.

ПРОТОКОЛ:
Якщо немає досвіду з GLP-1: старт першого тижня 1 мг/тиж., перевіряємо переносимість і підвищуємо до 2.5 до другого тижня, тримаємо дозування 3-4 тижні, далі титруємо за потреби.
Якщо досвід із GLP-1 (Ozempic/ Mounjaro тощо) був: початкову дозу вибираємо з урахуванням попередніх доз і переносимості.

ПОБІЧНІ ЕФЕКТИ:
Нудота, діарея/закреп, відрижка, важкість у шлунку (частіше на початку), можливе невелике зростання ЧСС.
Рідко: панкреатит, гіпоглікемія.

ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, тяжкі захворювання печінки й нирок, індивідуальна непереносимість. Обережно за наявності панкреатиту в анамнезі та вираженого гастропарезу.`},
cagrilintide:{review:'В оригінальному тексті не вказано тривалість етапів підвищення дози: фраза закінчується на «по». Діапазон, спільне застосування й перерви тут не підтверджені як призначення. Для календаря потрібна конкретна схема від фахівця; застосунок не доповнює її автоматично.',text:`Дози: 0.3-4.5 мг/тиж.
Тривалість: можна тривало; орієнтуємося на мету й переносимість (часто роблять перерву на 1 місяць кожні 4 місяці).

ПРОТОКОЛ:
Старт: 0.3 мг/тиж.
Далі за потреби титрування:
0.6 → 1.2 → 2.4 → 4.5 мг/тиж по
Якщо використовується разом із GLP-1: титруємо повільніше; багатьом вистачає діапазону 0.3-1.2 мг/тиж.

ПОБІЧНІ ЕФЕКТИ:
Нудота, відчуття переповнення/важкість, іноді закреп або діарея (частіше на старті й під час підвищення дози). Рідко: гіпоглікемія в поєднанні з інсуліном/сульфонілсечовиною.

ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, виражений гастропарез, індивідуальна непереносимість.
З обережністю за низької ваги й під час терапії інсуліном (може знадобитися зниження доз).`},
semax:{text:`Пептид
SEMAX
Дози: 200-300 мкг уранці або вдень для фокусу/роботи.
Тривалість: можна застосовувати тривало, практично не викликає звикання.
ПРОТОКОЛ:
День 1-3: 200 мкг/добу — оцінити ефект/переносимість.
Далі: 250-300 мкг/добу за відчуттями.
У ДНІ З ВИСОКИМ КОГНІТИВНИМ навантаженням — тримати верхню межу; увечері не застосовувати, щоб не заважати сну.
ПОБІЧНІ ЕФЕКТИ:
Рідко: легкий головний біль, короткочасна нервозність/«перегрів мозку» за завищення доз.
ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, індивідуальна непереносимість. З обережністю за вираженої тривоги й неконтрольованої гіпертонії.`},
selank:{text:`SELANK

Дози: 200-300 мкг в обід або ближче до вечора, але не перед сном, за 2-3 години.
Тривалість: можна застосовувати тривало.
ПРОТОКОЛ:
День 1-3: 200 мкг/добу — оцінити ефект/переносимість.
Далі: 250-300 мкг/добу за відчуттями.
За підвищеної тривоги в конкретний день — тримати верхню межу; можна ділити дозу на 2 прийоми (обід + ранній вечір).
ПОБІЧНІ ЕФЕКТИ:
Рідко: легка розслабленість/сонливість у чутливих.
ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік &lt;18 років, індивідуальна непереносимість. З обережністю за вираженої гіпотонії та приймання седативних засобів.`},
'glow-70':{text:`Пептид
GLOW 70

Суміш із 3 пептидів: GHK-Cu 50 мг / ТВ-500 10 мг / ВРС-157 10 мг.
РОЗВЕДЕННЯ: увесь флакон (70 мг) розвести в 3 мл бакводи.
ДОЗУВАННЯ: 15 ОД на шприці 100
UI (1 мл) щодня.
У 15 ОД така концентрація пептидів:
- GHK-Cu — 2.5 мг
- ТВ-500 — 0.5 мг
- ВРС-157 — 0,5 мг
Тривалість: мінімум 20 днів, оптимально 40-60 днів; за доброї відповіді — до 12 тижнів, потім перерва 4-8 тижнів.
ПРОТОКОЛ:
День 1-3: за чутливого ШКТ/низької маси тіла можна почати з 10 ОД. Далі: 15 ОД щодня (ранок або вечір — не критично).
ПОБІЧНІ ЕФЕКТИ:
Частіше: почервоніння/свербіж у місці
Рідко: легкий головний біль, сонливість/втома (через компонент ТВ-500), присмак «металу» (GHK-Cu).
ПРОТИПОКАЗАННЯ:
Вагітність, ретинопатія, лактація, вік <18 років, індивідуальна непереносимість.
З обережністю за порушень обміну міді (хвороба Вільсона), активних онкопроцесів і тяжких захворювань печінки.`},
dsip:{text:`Пептид
DSIP

ДОЗУВАННЯ: 100-300 мкг за 30-60 хв до сну.
Тривалість: 8 тижнів курс
→ 8 тижнів перерва; за потреби повторити.
ПРОТОКОЛ:
День 1-3: 100 мкг/добу — оцінити ефект/переносимість.
Далі: підвищувати на 50 мкг кожні 2-3 дні до 150-300 мкг.
Якщо є ранкова сонливість — прийняти раніше (за 60-90 хв до сну) або знизити дозу.
ПОБІЧНІ ЕФЕКТИ:
Рідко: ранкова млявість/«сонний слід», насичені сни.
ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, індивідуальна непереносимість. З обережністю під час приймання седативних/снодійних і вживання алкоголю перед сном.`},
'nad-plus':{text:`Кофермент
NAD+

Флакон 500 мг розводимо в 3 мл бакводи
ДОЗУВАННЯ: за протоколом нижче (підшкірно)
Тижні з 1 по 2: 25 мг (15 од) 2 рази на тиж.
Тижні з 3 по 4: 50 мг (30 од) 2 рази на тиж.
Тижні з 5 по 6: 100 мг (60 од) 1-2 рази на тиж.
7 тиждень+ (підтримка): 100 мг (60 од) 1 раз на тиж. (за потреби
2 рази на тиж. або ділити на мікродози).
ТРИВАЛІСТЬ:
за метою; після б-го тижня — режим підтримки. На один курс з віали.
ПОБІЧНІ ЕФЕКТИ:
Короткочасне тепло/почервоніння, легка нудота або запаморочення; за швидкого введення — печіння в місці ін’єкції, дискомфорт.
ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік <18 років, індивідуальна непереносимість. З обережністю за мігрені та вираженої гіпотонії.
ПАМ’ЯТКА:
Вводити повільно, достатньо пити воду; зберігати за 2-8 °С; розводити стерильно, не трясти; чергувати місця ін’єкцій. Можна комбінувати з MOTS-с/SS-31 для мітохондріальної підтримки.`},
'mots-c':{text:`Пептид
MOTS-C

Тривалість: 4-8 тижнів, далі перерва 2-4 тижні; повторювати залежно від мети.
ПРОТОКОЛ:
1. ЛАЙТ — 5 мг на тиждень
Схема: 1 мг на день із понеділка до п’ятниці
(вихідні — пауза).
2. ПРО — 10 мг на тиждень
Схема: 2 мг на день із понеділка до п’ятниці
(вихідні — пауза).
ПОБІЧНІ ЕФЕКТИ:
Іноді: легка реакція в місці ін’єкції, короткочасна втома/тепло. За вираженого дискомфорту — знизити дозу або зробити паузу.
ПРОТИПОКАЗАННЯ:
Вагітність, лактація, вік &lt;18 років, індивідуальна непереносимість. З обережністю за гострих захворювань і приймання антикоагулянтів (обговорити з лікарем).
ПРИМІТКИ:
Завжди починаємо з малої дози: перше введення — 1 мг (оцінити переносимість протягом доби).
Колоти після їжі та/або за 1-2 години до тренування.
На курсі додати метилфолат (вітамін B9) і контролювати гомоцистеїн. Орієнтир щодо В9:
800-5000 мкг/добу, індивідуально.
Удома мати під рукою антигістамінний засіб.
Чергуйте місця ін’єкцій; питний режим і сон посилюють ефект.`},
'bpc-157':{text:`Пептид
ВPС-157

Тривалість: 30-60 днів, за потреби до 4 місяців, потім перерва 4-8 тижнів.
ПРОТОКОЛ:
1. ЛАЙТ (ШКТ / м’яке загоєння)
250 мкг 2 рази на день (ранок/вечір).
2. ПРО (зв’язки/м’язи/ШКТ активніше)
500 мкг 2 рази на день (разом 1000 мкг/добу = 1 мг/добу). Можна ділити на 3 прийоми (300-300-400 мкг), оскільки пептид має досить короткий період напіввиведення.
3. ЕКСТРА (короткий інтенсив за гострої травми/загострення ШКТ)
1000 мкг (1 мг) уранці + 1000 мкг (1 мг) увечері
= 2 мг/добу 7-14 днів, потім знизити до 500 мкг 2 рази/день ще 2-4 тижні.
ПОБІЧНІ ЕФЕКТИ:
Місцеві: почервоніння/печіння, ущільнення.
Системні: печія/нудота, головний біль, запаморочення, сонливість або, навпаки, збудження. На високих дозах частіше виникають ШКТ-дискомфорт і місцеві реакції; зазвичай минають після зниження дози.
ПРОТИПОКАЗАННЯ:
Вагітність, ретинопатія, лактація, <18 років, індивідуальна непереносимість. З обережністю за активних злоякісних пухлин і проліферативних станів (ризик посилення ангіогенезу/загоєння). На антикоагулянтах — погодити з лікарем.`},
'ara-290':{text:`Пептид
ARA-290 / Cibinetide
АДМІН
ARA-290 — тканинозахисний і протизапальний пептид. Допомагає знижувати запальний фон, підтримувати відновлення нервових волокон, чутливість, біль за нейропатії та відновлення тканин після хронічного запалення.
Розведення: 10 мг + 1 мл бак. води
Вводити: підшкірно, 1 раз на день
Час: уранці або вдень, їжа не принципова
Курс: 4-8 тижнів
ПРОТОКОЛ:
Тиждень 1 — м’який старт: 2 мг/день, це 20 ОД на інсуліновому шприці 100
Тижні 2 і далі — робоче дозування: 4 мг/день, це 40 ОД на інсуліновому шприці 100 UI
Якщо на 4 мг з’являється виражена слабкість, головний біль, нудота або погіршення самопочуття — повернутися до 2 мг ще на кілька днів і підвищувати пізніше.
ВИТРАТА НА КУРС:
На 4 тижні: 10 віал по 10 мг
На 8 тижнів: 21 віала по 10 мг
ПОБІЧНІ ЕФЕКТИ:
Зазвичай переносимість добра, але можливі:
місцева реакція в місці уколу
головний біль
втома / слабкість
нудота
відчуття «ломоти» або посилення симптомів у перші дні
індивідуальна алергічна реакція
Якщо виражена слабкість, сонливість або погіршення стану — знизити дозу до 2 мг або зробити паузу.

ПРОТИПОКАЗАННЯ:
Не використовувати:
вагітність / лактація
вік до 18 років
активна онкологія
індивідуальна непереносимість
гострі тяжкі стани без контролю лікаря
З обережністю й краще через лікаря:
аутоімунні захворювання в активній фазі
тяжкі захворювання печінки / нирок
виражені серцево-судинні захворювання
діабет з ускладненнями, особливо за нейропатії
приймання імунобіологічної терапії або імуносупресорів
ПРИМІТКИ:
ARA-290 — дослідницький пептид, не стандартний лікарський засіб. Реалізується виключно з науково-дослідною метою. Продукт не призначений для вживання в їжу, діагностики, лікування або профілактики будь-яких захворювань. Придбати його можуть лише ліцензовані наукові установи й дослідники. Усі дослідження мають проводитися в суворій відповідності до чинного законодавства, норм біоетики та правил лабораторної практики.`}
};
for(const p of protocolReferences){const translated=ukrainianReferences[p.id];if(translated)Object.assign(p,translated)}

const ownProtocols=()=>state.protocols||[],ownPlans=()=>state.plans||[];
function realDate(s){return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s+'T12:00:00Z'))&&new Date(s+'T12:00:00Z').toISOString().slice(0,10)===s}
function realTime(s){return typeof s==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(s)}
function addDate(s,n){const d=new Date(s+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
function validStages(stages){const integer=(n,min,max)=>Number.isInteger(n)&&n>=min&&n<=max;return Array.isArray(stages)&&stages.length>0&&stages.length<=16&&stages.every(s=>s&&Number.isFinite(s.doseMcg)&&s.doseMcg>0&&s.doseMcg<=1e9&&integer(s.count,1,104)&&(s.scheduleMode==='cycle'?integer(s.onDays,1,90)&&integer(s.offDays,1,90):(!s.scheduleMode||s.scheduleMode==='interval')&&integer(s.intervalDays,1,90)))&&stages.reduce((a,s)=>a+s.count*(s.scheduleMode==='cycle'?s.onDays+s.offDays:s.intervalDays),0)<=730}
function validProtocol(p){return p&&typeof p.id==='string'&&typeof p.name==='string'&&p.name.trim().length>0&&typeof p.peptide==='string'&&p.peptide.trim().length>0&&typeof p.notes==='string'&&realTime(p.time)&&validProtocolTimes(p)&&validStages(p.stages)}
function validProtocolState(s){return(s.protocols===undefined||Array.isArray(s.protocols)&&s.protocols.length<=500&&s.protocols.every(validProtocol)&&new Set(s.protocols.map(p=>p.id)).size===s.protocols.length)&&(s.plans===undefined||Array.isArray(s.plans)&&s.plans.length<=500&&s.plans.every(p=>validProtocol(p)&&realDate(p.start)&&p.start<='9997-12-31'&&typeof p.vialId==='string'&&typeof p.stopped==='boolean'&&(p.excludedEvents===undefined||Array.isArray(p.excludedEvents)&&p.excludedEvents.length<=2190&&p.excludedEvents.every(id=>typeof id==='string')))&&new Set(s.plans.map(p=>p.id)).size===s.plans.length)}
function planEvents(p){if(!validProtocol(p)||!realDate(p.start))throw Error('Неповна схема протоколу.');let offset=0,index=0;const events=[],times=[...protocolTimes(p)].sort();p.stages.forEach((stage,phase)=>{for(let i=0;i<stage.count;i++){const activeDays=stage.scheduleMode==='cycle'?stage.onDays:1;for(let day=0;day<activeDays;day++)for(const time of times)events.push({id:p.id+'-'+index++,planId:p.id,date:addDate(p.start,offset+day),time,doseMcg:stage.doseMcg,phase:phase+1,peptide:p.peptide});offset+=stage.scheduleMode==='cycle'?stage.onDays+stage.offDays:stage.intervalDays}});return events.filter(e=>!(p.excludedEvents||[]).includes(e.id))}
function doseText(n){return n>=1000?precise(n/1000)+' мг':precise(n)+' мкг'}
function stageSummary(p){return p.stages.map((s,i)=>`<div class="protocol-stage"><span class="phase-index">${i+1}</span><strong>${doseText(s.doseMcg)}</strong><span>${s.scheduleMode==='cycle'?`${s.onDays} дн. введень / ${s.offDays} дн. перерви · ${s.count} циклів`:`кожні ${s.intervalDays} дн. · ${s.count} дн. введення`}</span><span>${protocolTimes(p).length} раз/день</span></div>`).join('')}
function protocolView(){return title('База протоколів','Виберіть свою збережену схему або створіть нову.',`<button class="primary" data-proto="create">+ Створити свій</button>`)+`<section class="protocol-section"><div class="card-head"><h2>Мої протоколи</h2><span class="tag">${ownProtocols().length}</span></div>${ownProtocols().length?`<div class="cards">${ownProtocols().map(p=>`<article class="card protocol-custom"><div class="card-head"><h2>${esc(p.name)}</h2><span class="tag teal">Моя схема</span></div><p class="subtitle">${esc(p.peptide)} · ${protocolTimes(p).map(esc).join(" / ")}</p><div class="protocol-stages">${stageSummary(p)}</div>${p.notes?`<p class="protocol-note">${esc(p.notes)}</p>`:''}<div class="actions"><button class="primary" data-proto="choose" data-id="${esc(p.id)}">Вибрати протокол</button><button class="secondary" data-proto="edit" data-id="${esc(p.id)}">Змінити</button><button class="delete-btn" data-proto="delete" data-id="${esc(p.id)}">Видалити</button></div></article>`).join('')}</div>`:`<section class="card">${empty('Збережених схем поки немає','Внесіть дози, інтервали й кількість введень із вашого призначення.')}<button class="secondary" data-proto="create">Створити перший протокол</button></section>`}</section><section class="protocol-section"><div class="card-head"><h2>Довідкові картки</h2><span class="tag">Карток: ${protocolReferences.length}</span></div><p class="subtitle">Оригінальні тексти автора. Вони не заповнюють дози в особистому розкладі автоматично.</p><div class="reference-protocol-grid">${protocolReferences.map(p=>`<article class="card protocol-reference"><div class="card-head"><h2>${p.name}</h2></div><span class="tag">Потребує уточнення</span>${p.review?`<div class="protocol-review">${esc(p.review)}</div>`:""}<details><summary>Дози, ефекти, протипоказання</summary><div class="notice">Текст автора, не перевірене призначення. Переліки ризиків і протипоказань можуть бути неповними.</div><div class="protocol-original">${esc(p.text.replaceAll("&lt;","<"))}</div></details><button class="secondary" data-proto="from-reference" data-id="${p.id}">Створити мою схему</button></article>`).join('')}</div></section>`}
function stageFields(s={},i=0){const cycle=s.scheduleMode==='cycle';return `<div class="stage-editor"><div class="stage-editor-title"><b>Етап <span class="stage-number">${i+1}</span></b><button type="button" class="delete-btn" data-proto="remove-stage">Видалити етап</button></div><div class="stage-fields"><label>Доза кожного введення<input data-stage="dose" type="number" min="0.000001" step="any" required value="${s.doseMcg?s.doseMcg/(s.doseMcg>=1000?1000:1):''}"></label><label>Одиниця<select data-stage="unit"><option value="mg" ${!s.doseMcg||s.doseMcg>=1000?'selected':''}>мг</option><option value="mcg" ${s.doseMcg&&s.doseMcg<1000?'selected':''}>мкг</option></select></label><label class="full">Як повторювати<select data-stage="mode"><option value="interval" ${!cycle?'selected':''}>Через інтервал днів</option><option value="cycle" ${cycle?'selected':''}>Дні введень і перерви</option></select></label><label data-schedule-interval ${cycle?'hidden':''}>Інтервал, днів<input data-stage="interval" type="number" min="1" max="90" step="1" required ${cycle?'disabled':''} value="${s.intervalDays??7}"></label><label data-schedule-cycle ${!cycle?'hidden':''}>Днів введень поспіль<input data-stage="on" type="number" min="1" max="90" step="1" required ${!cycle?'disabled':''} value="${s.onDays??5}"></label><label data-schedule-cycle ${!cycle?'hidden':''}>Днів перерви<input data-stage="off" type="number" min="1" max="90" step="1" required ${!cycle?'disabled':''} value="${s.offDays??2}"></label><label><span data-count-label>${cycle?'Кількість циклів':'Днів введення'}</span><input data-stage="count" type="number" min="1" max="104" step="1" required value="${s.count??''}"></label></div></div>`}
function readStages(){return [...document.querySelectorAll('.stage-editor')].map(row=>{const val=k=>row.querySelector('[data-stage="'+k+'"]').value,common={doseMcg:Number(val('dose'))*(val('unit')==='mg'?1000:1),count:Number(val('count'))};return val('mode')==='cycle'?{...common,scheduleMode:'cycle',onDays:Number(val('on')),offDays:Number(val('off'))}:{...common,intervalDays:Number(val('interval'))}})}
function openProtocolEditor(id,refId){const p=ownProtocols().find(p=>p.id===id),ref=protocolReferences.find(p=>p.id===refId);$('#dialog-title').textContent=p?'Змінити протокол':'Мій протокол';const form=$('#record-form');form.innerHTML=`<div class="form-grid">${field('name','Назва','text',p?.name||ref?.name||'',true)}${field('peptide','Пептид','text',p?.peptide||ref?.name||'',true)}${protocolTimeFields(p||{time:'09:00'})}${textfield('notes','Нотатки',p?.notes||'')}</div>${ref?`<div class="notice">${ref.review?esc(ref.review)+" ":""}Введіть конкретні етапи з індивідуального призначення; початкові дози не підставляються.</div>`:'<p class="unit">Перенесіть погоджену з фахівцем схему. Кожен етап містить фіксовану дозу та інтервал.</p>'}<div id="stage-list">${(p?.stages||[{}]).map(stageFields).join('')}</div><button type="button" class="secondary" data-proto="add-stage">+ Додати етап</button><p class="unit">Наступний етап починається після інтервалу попереднього етапу або повного останнього циклу, включно з перервою. Після останнього етапу схема не продовжується автоматично.</p><p class="error" id="protocol-error" role="alert"></p><div class="form-actions"><button type="button" class="secondary" data-proto="close">Скасувати</button><button type="submit" class="primary">Зберегти протокол</button></div>`;form.onsubmit=e=>{e.preventDefault();const data=Object.fromEntries(new FormData(form)),record={id:p?.id||crypto.randomUUID(),name:data.name.trim(),peptide:data.peptide.trim(),time:readProtocolTimes(form)[0],times:readProtocolTimes(form),notes:data.notes.trim(),stages:readStages()};if(!validProtocol(record)){$('#protocol-error').textContent='Укажіть 1–3 різні часи й заповніть кожен етап: додатна доза, цілий інтервал і число днів введення. Загальна тривалість схеми — до 730 днів.';return}const next={...state,protocols:p?ownProtocols().map(v=>v.id===p.id?record:v):[...ownProtocols(),record]};if(commit(next)){$('#dialog').close();notify('Протокол збережено. Його можна вибрати для календаря.')}};$('#dialog').showModal()}
let stagedPlan=null;
function matchingVials(peptide){return state.vials.filter(v=>v.peptide.trim().toLowerCase()===peptide.trim().toLowerCase())}
function openPlanForm(id){const p=ownProtocols().find(p=>p.id===id);if(!p)return;stagedPlan={...JSON.parse(JSON.stringify(p)),id:crypto.randomUUID(),protocolId:p.id,start:today(),vialId:'',stopped:false};$('#dialog-title').textContent='Запланувати: '+p.name;const form=$('#record-form');form.innerHTML=`<p class="subtitle">${esc(p.peptide)} · етапи й дози перенесено з вашого протоколу.</p><div class="protocol-stages">${stageSummary(p)}</div><div class="form-grid">${field('start','Перше введення','date',stagedPlan.start,true)}${protocolTimeFields(p,false)}<label class="full">Флакон для калькулятора<select name="vialId"><option value="">Без прив’язки — заповнити концентрацію пізніше</option>${matchingVials(p.peptide).map(v=>`<option value="${esc(v.id)}">${esc(v.peptide)} #${esc(v.number)} · ${fmt(v.mass)} мг / ${fmt(v.water)} мл</option>`).join('')}</select></label></div><p class="unit">Розклад використовує вибрані дату й час за місцевим часом пристрою. Сповіщення поза застосунком не надсилаються.</p><div id="plan-preview"></div><p class="error" id="protocol-error" role="alert"></p><div class="form-actions"><button type="button" class="secondary" data-proto="close">Скасувати</button><button type="submit" class="primary">Додати до планувальника</button></div>`;const preview=()=>{const data=Object.fromEntries(new FormData(form));const times=readProtocolTimes(form);stagedPlan={...stagedPlan,start:data.start,vialId:data.vialId,time:times[0],times};if(realDate(stagedPlan.start)&&validProtocol(stagedPlan)){const events=planEvents(stagedPlan);$('#plan-preview').innerHTML=`<h3>Попередній перегляд · ${events.length} введ.</h3><p class="unit">${date(events[0]?.date)} — ${date(events.at(-1)?.date)} · усього ${doseText(events.reduce((a,e)=>a+e.doseMcg,0))}</p>${eventTable(stagedPlan,events.slice(0,8),true)}${events.length>8?'<p class="unit">Решта дат буде доступна в планувальнику.</p>':''}`}else $('#plan-preview').innerHTML=''};form.oninput=preview;form.onchange=preview;preview();form.onsubmit=e=>{e.preventDefault();preview();if(!validProtocolState({plans:[stagedPlan]})){$('#protocol-error').textContent='Перевірте дату, етапи й 1–3 різні часи введення.';return}if(commit({...state,plans:[...ownPlans(),stagedPlan]})){$('#dialog').close();location.hash='planner';notify('Розклад додано')}};$('#dialog').showModal()}
function doneEntry(event){return state.entries.find(e=>e.planEventId===event.id)}
function eventTable(plan,events,preview=false){return `<div class="table-wrap"><table><thead><tr><th>Дата / час</th><th>Етап</th><th>Доза за планом</th>${preview?'':'<th>Позначка</th><th>Дії</th>'}</tr></thead><tbody>${events.map(e=>{const done=doneEntry(e);return `<tr><td>${date(e.date)} · ${e.time}</td><td>${e.phase}</td><td><strong>${doseText(e.doseMcg)}</strong></td>${preview?'':`<td><span class="tag ${done?'teal':''}">${done?'У журналі':!eventIsUpcoming(e)?'Час минув':'Заплановано'}</span></td><td><div class="actions"><button class="edit-btn" data-proto="calculate-event" data-plan="${esc(plan.id)}" data-event="${esc(e.id)}">Шприц</button><button class="edit-btn" data-proto="log-event" data-plan="${esc(plan.id)}" data-event="${esc(e.id)}">${done?'Відкрити запис':'Записати факт'}</button></div></td>`}</tr>`}).join('')}</tbody></table></div>`}
function activeProtocolCount(){return ownPlans().filter(p=>{const events=planEvents(p);return!p.stopped&&p.start<=today()&&events.at(-1)?.date>=today()}).length}
function plansView(){return `<section class="protocol-section"><div class="card-head"><h2>Розклади за протоколами</h2><button class="secondary" data-go="protocols">Вибрати протокол</button></div>${ownPlans().length?ownPlans().map(p=>{const events=planEvents(p),done=events.filter(doneEntry).length,next=events.find(e=>eventIsUpcoming(e)&&!doneEntry(e)),vial=state.vials.find(v=>v.id===p.vialId);return `<article class="card plan-card"><div class="card-head"><div><h2>${esc(p.name)}</h2><p class="subtitle">${esc(p.peptide)} · ${date(p.start)} — ${date(events.at(-1)?.date)}</p></div><span class="tag ${p.stopped?'':'teal'}">${p.stopped?'Зупинено':!events.length?'Немає введень':events.at(-1)?.date<today()?'Період завершено':p.start>today()?'Заплановано':'Активен'}</span></div><div class="plan-highlight"><div><span>${p.stopped?'Розклад зупинено':next?'Наступна дата за планом':'Майбутніх дат немає'}</span><strong>${!p.stopped&&next?date(next.date)+' · '+next.time:'—'}</strong></div><div><span>Доза за планом</span><strong>${!p.stopped&&next?doseText(next.doseMcg):'—'}</strong></div><div><span>Записано фактично</span><strong>${done} / ${events.length}</strong></div></div><p class="unit">Флакон: ${vial?esc(vial.peptide)+' #'+esc(vial.number):p.vialId?'Видалено з переліку флаконів; виберіть інший.':'не вибрано'}. Розрахунок об’єму використовує поточні дані вибраного флакона.</p><div class="actions"><button class="secondary" data-proto="change-vial" data-id="${esc(p.id)}">Вибрати флакон</button><button class="secondary" data-proto="toggle-plan" data-id="${esc(p.id)}">${p.stopped?'Відновити':'Зупинити'}</button><button class="delete-btn" data-proto="delete-plan" data-id="${esc(p.id)}">Видалити розклад</button></div><details class="plan-calendar" ${p.stopped?'':'open'}><summary>Усі дати й дози · ${events.length}</summary>${eventTable(p,events)}</details><p class="unit">Минулі дати не переносяться й не вважаються виконаними автоматично. Записуйте лише фактично виконані введення.</p></article>`}).join(''):`<section class="card">${empty('Виберіть протокол для календаря','Дози й інтервали підтягнуться зі збереженої схеми; залишиться вказати дату початку.')}</section>`}</section>`}
function upcomingProtocolView(){const events=ownPlans().filter(p=>!p.stopped).flatMap(p=>planEvents(p).filter(e=>eventIsUpcoming(e)&&!doneEntry(e)).map(e=>({...e,name:p.name}))).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,3);return events.length?`<section class="card upcoming-protocol"><div class="card-head"><h2>Найближче за протоколами</h2><a href="#planner" class="text-button">Планувальник</a></div>${events.map(e=>`<div class="upcoming-row"><div><b>${esc(e.name)}</b><p class="unit">${date(e.date)} · ${e.time}</p></div><strong>${doseText(e.doseMcg)}</strong><button class="secondary" data-proto="calculate-event" data-plan="${esc(e.planId)}" data-event="${esc(e.id)}">Шприц</button></div>`).join('')}</section>`:''}
function plannedCalcData(p,e){const v=state.vials.find(v=>v.id===p.vialId);return {name:p.peptide,mass:v?.mass??'',water:v?.water??'',dose:e.doseMcg,doseUnit:'mg',syringe:p.syringe||'u100-1',fromPlan:true}}
function changePlanVial(id){const p=ownPlans().find(p=>p.id===id);if(!p)return;$('#dialog-title').textContent='Флакон для '+p.name;const form=$('#record-form');form.innerHTML=`<label>Флакон<select name="vialId"><option value="">Без прив’язки</option>${matchingVials(p.peptide).map(v=>`<option value="${esc(v.id)}" ${v.id===p.vialId?'selected':''}>${esc(v.peptide)} #${esc(v.number)} · ${fmt(v.mass)} мг / ${fmt(v.water)} мл</option>`).join('')}</select></label><p class="unit">Якщо флакон не відображається, додайте його до переліку флаконів із такою самою назвою пептиду.</p><div class="form-actions"><button type="button" class="secondary" data-proto="close">Скасувати</button><button type="submit" class="primary">Зберегти</button></div>`;form.onsubmit=e=>{e.preventDefault();const vialId=new FormData(form).get('vialId');if(commit({...state,plans:ownPlans().map(v=>v.id===p.id?{...v,vialId}:v)})){$('#dialog').close();notify('Флакон вибрано')}};$('#dialog').showModal()}
function clearProtocolForm(){const f=$('#record-form');f.oninput=null;f.onchange=null;f.onsubmit=null}
function planner(){return title('Планувальник','Дати й дози з ваших збережених протоколів.',`<button class="secondary" data-add="cycles">Вільний цикл</button><button class="primary" data-go="protocols">Вибрати протокол</button>`)+plansView()+(state.cycles.length?`<details class="manual-cycles"><summary>Вільні цикли · ${state.cycles.length}</summary>${legacyPlanner()}</details>`:'')}
document.addEventListener('click',event=>{const b=event.target.closest('[data-proto]');if(!b)return;const a=b.dataset.proto,id=b.dataset.id;if(['create','edit','from-reference','choose','change-vial'].includes(a))clearProtocolForm();if(a==='close')$('#dialog').close();if(a==='create')openProtocolEditor();if(a==='edit')openProtocolEditor(id);if(a==='from-reference')openProtocolEditor(undefined,id);if(a==='choose')startFlow({protocolId:id});if(a==='change-vial')changePlanVial(id);if(a==='add-stage'){const n=document.querySelectorAll('.stage-editor').length;if(n>=16){notify('Можна додати до 16 етапів.');return}$('#stage-list').insertAdjacentHTML('beforeend',stageFields({},n))}if(a==='remove-stage'){if(document.querySelectorAll('.stage-editor').length===1){notify('Потрібен хоча б один етап.');return}b.closest('.stage-editor').remove();document.querySelectorAll('.stage-number').forEach((s,i)=>s.textContent=i+1)}if(a==='delete'&&confirm('Видалити протокол із бази? Створені розклади й журнал збережуться.'))commit({...state,protocols:ownProtocols().filter(p=>p.id!==id)});if(a==='delete-plan'&&confirm('Видалити цей розклад? Фактичні записи залишаться в журналі.'))commit({...state,plans:ownPlans().filter(p=>p.id!==id)});if(a==='toggle-plan'){const p=ownPlans().find(p=>p.id===id);if(p&&confirm(p.stopped?'Відновити розклад із попередніми датами? Минулі введення не переносяться.':'Зупинити цей розклад?'))commit({...state,plans:ownPlans().map(v=>v.id===id?{...v,stopped:!v.stopped}:v)})}if(a==='calculate-event'||a==='log-event'){const p=ownPlans().find(p=>p.id===b.dataset.plan);if(!p)return;const e=planEvents(p).find(e=>e.id===b.dataset.event);if(!e)return;if(a==='calculate-event'){calc=plannedCalcData(p,e);location.hash='calculator';render()}else{clearProtocolForm();const recorded=doneEntry(e);if(recorded)openForm('entries',recorded.id);else{const v=state.vials.find(v=>v.id===p.vialId);openForm('entries',undefined,{peptide:p.peptide,dose:e.doseMcg,units:'',vialId:v?.id||'',vial:v?v.peptide+' #'+v.number:'',notes:'За протоколом «'+p.name+'». Планова дата: '+date(e.date)+' '+e.time+'. Перевірте фактичні дату, час і дозу.',planEventId:e.id})}}}});

document.addEventListener('change',e=>{if(!e.target.matches?.('[data-stage="mode"]'))return;const row=e.target.closest('.stage-editor'),cycle=e.target.value==='cycle';for(const el of row.querySelectorAll('[data-schedule-cycle]')){el.hidden=!cycle;el.querySelector('input').disabled=!cycle}const interval=row.querySelector('[data-schedule-interval]');interval.hidden=cycle;interval.querySelector('input').disabled=cycle;row.querySelector('[data-count-label]').textContent=cycle?'Кількість циклів':'Днів введення';row.querySelector('[data-stage="count"]').value=''},true);
