'use strict';
function protocolTimes(p){return p.times||[p.time||'09:00']}
function validProtocolTimes(p){return p.times===undefined||(Array.isArray(p.times)&&p.times.length>=1&&p.times.length<=3&&p.times.every(realTime)&&new Set(p.times).size===p.times.length&&p.time===p.times[0])}
function dailyTimeInputs(times){return times.map((t,i)=>`<label>Введення ${i+1}<input data-dose-time name="time${i}" type="time" value="${esc(t)}" required></label>`).join('')}
function protocolTimeFields(p,allowCount=true){const times=protocolTimes(p);return `<div class="full daily-times"><div class="daily-times-head"><h3>Введення на день</h3>${allowCount?`<select data-daily-count aria-label="Кількість введень на день">${[1,2,3].map(n=>`<option value="${n}" ${n===times.length?'selected':''}>${n} ${n===1?'раз':'рази'} на день</option>`).join('')}</select>`:`<span class="tag">${times.length} ${times.length===1?'раз':'рази'} на день</span>`}</div><div class="daily-time-inputs">${dailyTimeInputs(times)}</div><p class="unit">Окремий запис для кожного часу в день розкладу. Дозу етапу вказано на одне введення.</p></div>`}
function readProtocolTimes(form){return [...form.querySelectorAll('[data-dose-time]')].map(e=>e.value).sort()}
document.addEventListener('change',e=>{if(!e.target.matches?.('[data-daily-count]'))return;const container=e.target.closest('.daily-times'),old=[...container.querySelectorAll('[data-dose-time]')].map(i=>i.value),count=Number(e.target.value);if(![1,2,3].includes(count))return;const times=Array.from({length:count},(_,i)=>old[i]||'');container.querySelector('.daily-time-inputs').innerHTML=dailyTimeInputs(times)});

function eventIsUpcoming(e){return e.date+'T'+e.time>=today()+'T'+new Date().toTimeString().slice(0,5)}
