'use strict';
const syringeTypes = {
  'u100-1': {label:'U-100',capacity:1,scale:100,major:10,minor:2},
  'u100-05': {label:'U-100',capacity:0.5,scale:100,major:5,minor:1},
  'u100-03': {label:'U-100',capacity:0.3,scale:100,major:5,minor:1},
  'u40-1': {label:'U-40',capacity:1,scale:40,major:5,minor:1}
};
function precise(value) {
  return value>0 && value<0.0001
    ? value.toLocaleString('uk-UA',{maximumSignificantDigits:4})
    : value.toLocaleString('uk-UA',{maximumFractionDigits:4});
}
function syringeReading(volume,type) {
  const syringe=syringeTypes[type];
  if(!syringe || !Number.isFinite(volume) || volume<=0) throw Error('Перевірте об’єм і вибраний шприц.');
  const units=volume*syringe.scale,maximum=syringe.capacity*syringe.scale;
  if(!Number.isFinite(units)) throw Error('Значення завеликі для розрахунку.');
  return {...syringe,units,maximum,ratio:volume/syringe.capacity,overflow:volume>syringe.capacity+Number.EPSILON*4};
}
function syringeSvg(reading,volume) {
  if(reading.overflow) return '';
  const start=65,length=500,end=start+length,position=start+length*Math.min(reading.ratio,1);
  const markerText=reading.units<0.0001?reading.units.toExponential(2).replace('.',','):precise(reading.units);
  const badgeWidth=Math.max(66,markerText.length*12+18);
  const badgeLeft=Math.max(4,Math.min(656-badgeWidth,position-badgeWidth/2));
  const ticks=[];
  // Both the fill boundary and the needle-facing edge of the piston use the exact volume ratio.
  for(let unit=0;unit<=reading.maximum;unit++) {
    if(unit%reading.minor!==0 && unit%reading.major!==0) continue;
    const x=start+unit/reading.maximum*length,major=unit%reading.major===0;
    ticks.push(`<line x1="${x}" y1="48" x2="${x}" y2="${major?72:61}" stroke="#6b858d" stroke-width="${major?1.5:1}"/>`);
  }
  const labels=[];
  for(let unit=0;unit<=reading.maximum;unit+=reading.major) {
    const x=start+unit/reading.maximum*length;
    labels.push(`<text class="scale-label ${(unit/reading.major)%2===1&&unit!==reading.maximum?'scale-label-secondary':''}" x="${x}" y="32" text-anchor="middle">${unit}</text>`);
  }
  return `<svg class="syringe-svg" viewBox="0 0 660 155" role="img" aria-labelledby="syringe-svg-title syringe-svg-description"><title id="syringe-svg-title">Шкала ${reading.label}: позначка ${precise(reading.units)}</title><desc id="syringe-svg-description">${precise(volume)} мл із ${precise(reading.capacity)} мл. Заповнено ${precise(reading.ratio*100)} відсотка об’єму. Ліворуч нуль; праворуч ${reading.maximum}.</desc><line x1="8" y1="76" x2="48" y2="76" stroke="#859aa3" stroke-width="2"/><rect x="43" y="68" width="22" height="16" rx="3" fill="#9db4b8"/><rect x="65" y="48" width="500" height="56" rx="3" fill="#FEFDF9" stroke="#90aaaf" stroke-width="2"/><rect data-syringe-fill x="65" y="49" width="${length*Math.min(reading.ratio,1)}" height="54" fill="#838BCC"/><line x1="${position+7}" y1="76" x2="637" y2="76" stroke="#a4babc" stroke-width="7"/><rect x="${position}" y="49" width="7" height="54" rx="1" fill="#343A64"/>${ticks.join('')}${labels.join('')}<line x1="565" y1="38" x2="565" y2="113" stroke="#90aaaf" stroke-width="7" stroke-linecap="round"/><line x1="637" y1="56" x2="637" y2="96" stroke="#a4babc" stroke-width="9" stroke-linecap="round"/><line data-syringe-marker x1="${position}" x2="${position}" y1="100" y2="124" stroke="#343A64" stroke-width="2"/><rect x="${badgeLeft}" y="123" width="${badgeWidth}" height="27" rx="9" fill="#343A64"/><text x="${badgeLeft+badgeWidth/2}" y="142" text-anchor="middle" class="marker-label">${markerText}</text></svg>`;
}
function syringeResult(result,type) {
  const r=syringeReading(result.volume,type);
  return `<div class="syringe-heading"><span>РОЗРАХУНКОВА ПОЗНАЧКА</span><span class="syringe-type">${r.label} · ${precise(r.capacity)} мл</span></div><div class="syringe-number">${precise(r.units)} <span>за шкалою ${r.label}</span></div>${r.overflow?`<div class="capacity-error" role="status"><strong>Об’єм перевищує місткість шприца</strong><p>Розраховано ${precise(result.volume)} мл; вибраний шприц вміщує ${precise(r.capacity)} мл (до ${r.maximum} за шкалою). Позначку на ньому показати неможливо.</p></div>`:syringeSvg(r,result.volume)}<div class="syringe-summary"><div><span>Концентрація</span><strong>${precise(result.concentration/1000)} мг/мл</strong></div><div><span>Об’єм дози</span><strong>${precise(result.volume)} мл</strong></div></div><p class="syringe-caption">${r.overflow?'':'Темна межа заповнення показує розрахункову позначку. '}Шкала схематична; дрібні поділки залежать від моделі шприца. Доза не округлюється до найближчої поділки.</p>`;
}
