'use strict';
function stockBalance(v,entries=state.entries,excludeId=''){
  const related=entries.filter(e=>e.vialId===v.id&&e.id!==excludeId);
  const used=related.reduce((sum,e)=>sum+e.dose,0),total=v.mass*1000;
  const raw=total-used,tolerance=Math.max(total,used,1)*Number.EPSILON*16;
  const remaining=Math.abs(raw)<=tolerance?0:Math.max(0,raw);
  return {total,used,remaining,percent:remaining/total*100,count:related.length,excess:raw < -tolerance ? -raw : 0};
}
function normaliseStock(data){
  // Legacy free-text links are converted only when peptide and vial label identify exactly one vial.
  const norm=s=>String(s??'').trim().toLowerCase().replace(/\s+/g,' ');
  const entries=data.entries.map(e=>{
    if(typeof e.vialId==='string')return e;
    const matches=data.vials.filter(v=>norm(v.peptide)===norm(e.peptide)&&norm(e.vial)!==''&&[norm(v.number),norm('#'+v.number),norm(v.peptide+' #'+v.number)].includes(norm(e.vial)));
    return {...e,vialId:matches.length===1?matches[0].id:''};
  });
  return {...data,entries,vials:data.vials.map(v=>({...v,remaining:stockBalance(v,entries).percent}))};
}
function entryVialLabel(e){const v=state.vials.find(v=>v.id===e.vialId);return v?v.peptide+' #'+v.number:e.vial||'Не выбран'}
function entryVialCell(e){const linked=state.vials.some(v=>v.id===e.vialId);return `${esc(entryVialLabel(e))}${linked?'':'<br><span class="stock-unlinked">Не привязан — без списания</span>'}`}
function unlinkedStockNotice(){const count=state.entries.filter(e=>!state.vials.some(v=>v.id===e.vialId)).length;return count?`<div class="notice">Записей без привязки к флакону: <b>${count}</b>. Откройте их в журнале и выберите флакон, чтобы учесть расход. <a href="#journal">Открыть журнал</a></div>`:''}
function stockVialPicker(record,required){return `<label class="full">Флакон для списания<select name="vialId" ${required?'required':''}><option value="">Выберите флакон</option>${state.vials.map(v=>{const b=stockBalance(v,state.entries,record.id);return `<option value="${esc(v.id)}" ${record.vialId===v.id?'selected':''}>${esc(v.peptide)} #${esc(v.number)} · доступно ${precise(b.remaining/1000)} мг</option>`}).join('')}</select></label>${record.vial&&!record.vialId?`<p class="unit full">Прежняя запись: ${esc(record.vial)}. Выберите точный флакон для учёта расхода.</p>`:''}<div id="stock-preview" class="notice full"></div>`}
function bindStockForm(record){
  const form=$('#record-form'),picker=form.querySelector('[name="vialId"]'),dose=form.querySelector('[name="dose"]'),peptide=form.querySelector('[name="peptide"]');
  function update(){const v=state.vials.find(v=>v.id===picker.value);peptide.readOnly=!!v;if(!v){$('#stock-preview').textContent=state.vials.length?'Выберите флакон: расход рассчитывается по фактической дозе в мкг.':'Сначала добавьте флакон в разделе «Флаконы».';return}peptide.value=v.peptide;const b=stockBalance(v,state.entries,record.id),amount=Number(dose.value);if(!Number.isFinite(amount)||amount<=0){$('#stock-preview').textContent=`До этой записи: ${precise(b.remaining/1000)} мг. Введите дозу в мкг.`;return}const after=b.total-b.used-amount;$('#stock-preview').textContent=after < -1e-8?`Расход превысит содержимое флакона на ${precise(-after/1000)} мг. Проверьте дозу и выбранный флакон. Запись фактического введения можно сохранить; превышение будет показано в инвентаре.`:`После сохранения останется ${precise(Math.max(0,after)/1000)} мг (${precise(Math.max(0,after)/b.total*100)}%).`}
  picker.addEventListener('change',update);dose.addEventListener('input',update);update();
}
function stockAmount(v){const b=stockBalance(v);return `<strong>${precise(b.remaining/1000)} мг</strong><div class="row-meta">${fmt(b.percent,2)}% · списано ${precise(b.used/1000)} мг</div>${b.excess?`<div class="error">Превышение: ${precise(b.excess/1000)} мг</div>`:''}`}
